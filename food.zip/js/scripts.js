function open_nav(){
    const opennav= document.getElementById('nav')
    opennav.classList.add('open-nav')
}   

function close_nav(){
    const closenav = document.getElementById('nav')
    closenav.classList.remove('open-nav')
}




